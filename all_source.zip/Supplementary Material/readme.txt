`ascon_3r_coll.cpp`: the code to search the collision for 3-round Ascon-Hash. To compile, use the command `g++ ascon_3r_coll.cpp -o ascon`. To run, use the command `./ascon`


